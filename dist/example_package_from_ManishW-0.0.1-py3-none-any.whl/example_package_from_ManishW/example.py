def add_nums(number_1, number_2):
    return number_1 + number_2

